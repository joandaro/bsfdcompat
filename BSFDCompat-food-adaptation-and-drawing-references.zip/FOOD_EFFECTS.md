# 蔚蓝适应分配

对照来源是提供的 FarmersDelight-1.20.1-1.3.4.jar 的 FoodValues 字节码。
本模组的对应项是按食物类型选择的类比；并非农夫乐事原本存在这些蔚蓝食物。

| 本模组食物 | 对应农夫乐事食物 | 农夫乐事滋养 | 本次蔚蓝适应 |
| --- | --- | --- | --- |
| Venison Pie / 鹿肉派 | Shepherd's Pie / 牧羊人派 | 6000 tick，5 分钟 | 一级，5 分钟 |
| Glazed Monitor Tail / 蜜汁蜥尾 | Honey Glazed Ham / 蜜汁火腿 | 6000 tick，5 分钟 | 一级，5 分钟 |

该版本的三明治、汉堡、肉卷、饺子、菜卷和寿司 FoodValues 均不带滋养，因此本次对应料理也不加。
熟米饭本身有 30 秒滋养，但饭团按成品便携米饭食品对齐，不按原料效果叠加。
原生滋养不按“营养值超过某个阈值”统一分配；不是所有大餐以外的复杂合成都有。
十四种生/熟肉块与鱼片继续不加蔚蓝适应。
甜派在农夫乐事中有其他效果，本次只映射滋养，不复制速度等其他效果。

获得概率 100%，等级为 amplifier 0。食用时显示状态图标，不产生状态环绕粒子。
食物提示通过农夫乐事现成的 TextUtils.addFoodEffectTooltip 显示，遵循其 ENABLE_FOOD_EFFECT_TOOLTIP 配置。

完整的二十四种料理对照见 FOOD_EFFECTS.csv。

## 实现

ModItems 的 food 工厂增加一个以秒为单位的重载，原调用默认 0 秒。
仅 venison_pie 与 glazed_monitor_tail 传入 300 秒。
FoodProperties 使用 Supplier 延迟获取 SKY_ADAPTATION，不会在物品声明初始化时直接取注册对象。
所有食物的注册名、饥饿值、饱和度倍率及创造栏位置保持现有版本。
