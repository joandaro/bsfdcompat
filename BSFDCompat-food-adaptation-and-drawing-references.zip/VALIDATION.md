# 校验记录

- 当前项目全部 14 个 Java 文件通过 Java 17 语法解析，未进行外部依赖类型检查。
- 24 种料理的注册名、饥饿值和饱和度参数与上一包逐项一致；只有 venison_pie 和 glazed_monitor_tail 传入 300 秒效果。
- 效果使用 Supplier 延迟获取、amplifier 0、概率 1.0；300 × 20 = 6000 tick。
- 对照提供的 FD FoodValues，SHEPHERDS_PIE 和 HONEY_GLAZED_HAM 均提供 6000 tick 滋养；对应便携食品不含滋养。
- 对照提供的 FD jar，TextUtils.addFoodEffectTooltip 的方法签名和 ENABLE_FOOD_EFFECT_TOOLTIP 配置字段存在。
- 34 张 FD 底图、35 张蔚蓝参考图逐文件与源 jar 比较，字节完全一致，均为有效 PNG。
- 蔚蓝 food 目录内所有 35 张 PNG 都已复制，包括种子及 prepared_food 图层。
- 原有 51 张物品、方块及状态图标贴图的 SHA-256 均未改变。
- 没有任何物品模型引用 _drawing；Gradle 的资源目录已设置排除整个 _drawing 目录。
- 本地索引包含 69 个内嵌 PNG，无外部图片依赖。

未执行完整 Forge/Gradle 构建或游戏内食用测试；未通过实际构建检查最终 jar 的资源条目。
资源排除和运行行为仍需通过 clean build / 游戏测试确认。
