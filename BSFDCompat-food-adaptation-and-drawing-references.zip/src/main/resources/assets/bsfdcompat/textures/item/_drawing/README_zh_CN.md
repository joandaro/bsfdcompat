# 绘图底图与参考

打开 index.html 查看可搜索的缩略图索引。

- farmersdelight/by_item：34 张按咱们物品名命名的底图，直接复制原文件，没有修改图像。
- blue_skies/food：35 张蔚蓝食物目录原图，用于你要求的绘图参考，未被物品模型引用。
- material_map.csv：底图对应关系和建议。
- material_manifest.json：完整来源及文件哈希。

现有 textures/item 根目录的成品图没有覆盖。
完成编辑后，将自己的 PNG 放回 textures/item/<本模组物品名>.png。
本 _drawing 目录已通过 build.gradle 从资源构建中排除。

糖脆片、能量棒、马卡龙和现有软糖没有强行匹配不相似的底图。
