# 校验记录

- 当前项目全部 14 个 Java 源文件通过 Java 17 语法解析，未解析外部依赖进行类型检查。
- 只有 venison_pie 与 glazed_monitor_tail 使用 meal 工厂，均为 180 秒、amplifier 0、概率 1.0。
- 仅 meal 工厂启用碗容器与 stacksTo(16)，普通食物和六种零食不启用。
- 二十四种料理的注册名、饥饿值及饱和度与上个版本逐项一致，六种快吃分类保留。
- 两道烹饪配方明确要求 minecraft:bowl，产量仍为 1、烹饪时间仍为 800、经验仍为 1.0。
- 其他本模组配方没有新增 container 字段。
- 对照提供的农夫乐事 1.3.4 字节码，ConsumableItem 有 public 的 Properties 构造函数，其 finishUsingItem 包含末份返碗、背包插入及插入失败掉落容器的路径。
- 对照同一 jar，CookingPotRecipe.Serializer 支持 container 对象字段。
- AdaptationFoodItem 保留满饥饿入口，继承父类完成进食和提示；未重复重写父类的食物效果提示。
- 原有 51 张实际使用的 PNG 哈希均未改变，绘图索引仅更新了两处 5:00 为 3:00。

尚未执行完整 Forge/Gradle 构建、独立服务器启动、实际出锅或进食返碗测试。
