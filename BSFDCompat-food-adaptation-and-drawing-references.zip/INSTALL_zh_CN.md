# 食物蔚蓝适应与绘图素材

把本包的 build.gradle 和 src 合并到现有 bsfdcompat 项目根目录，覆盖同名文件。
本包以已经应用“蔚蓝创造栏 + Horizonite 专用熟制切割配方”的版本为基础。
没有增加 Mixin，也没有修改案板配方或刀具代码。

## 食物效果

按提供的农夫乐事 1.20.1-1.3.4 源实现对照：

- 鹿肉派：参照牧羊人派，获得一级蔚蓝适应 5 分钟。
- 蜜汁蜥尾：参照蜜汁火腿，获得一级蔚蓝适应 5 分钟。
- 三明治、汉堡、肉卷、饺子、菜卷、寿司、零食及生/熟切片不加。

不是按饥饿值大小一律加效果。详细依据和二十四种料理对照见 FOOD_EFFECTS.md / FOOD_EFFECTS.csv。
两道主菜的获得概率为 100%，隐藏状态粒子，保留图标。
有食物效果的物品现在可以显示农夫乐事样式的效果提示；若关闭农夫乐事食物效果提示配置，提示也不显示。

## 绘图目录

全部底图和参考图都在：

`src/main/resources/assets/bsfdcompat/textures/item/_drawing/`

直接打开其中的 `index.html`，可以按名称搜索、按来源切换，并放大查看像素图。
这是自包含的本地页面，不需要网络。

| 子目录或文件 | 内容 |
| --- | --- |
| farmersdelight/by_item/ | 34 张可作底图的农夫乐事原图，已按咱们的物品 ID 命名 |
| blue_skies/food/ | 35 张蔚蓝食物目录原图，保留原文件名，供绘图参考 |
| material_map.csv | 本模组物品、FD 源图、目标路径及修改建议 |
| material_manifest.json | 完整来源、文件路径、SHA-256 及蔚蓝物品模型对应关系 |
| farmersdelight/LICENSE.txt | 农夫乐事素材的 MIT 许可说明 |
| blue_skies/REFERENCE_ONLY.txt | 蔚蓝参考目录说明 |

底图包括饼干、叶卷、肉卷、寿司、汉堡、三明治、饺子、派、肉片和鱼片等。
有些属于直接微调素材，有些只能借用轮廓，具体建议在索引和 CSV 中。
糖脆片、能量棒、马卡龙没有直接相近的 FD 素材；已有软糖也没有拿不相似的图片覆盖。

蔚蓝原文件名中的 azulfo_raw / azulfo_cooked 分别对应 carabeef / cooked_carabeef；venison_raw / venison_cooked 对应生/熟鹿肉。
prepared_food 的四张图片是叠加图层，不是四种完整食品。
整个食物目录中的种子和图层也一起保留，方便你对照。

## 如何使用底图

现有正在被物品模型使用的 PNG 均未覆盖。
例如编辑 `farmersdelight/by_item/carabeef_roll.png`，完成后将自己的版本放回：

`src/main/resources/assets/bsfdcompat/textures/item/carabeef_roll.png`

模型继续指向这个已有位置，不需要改模型 JSON。
蔚蓝原图按你的要求供绘图参考，当前没有任何物品模型指向这些原图。

## 构建配置

build.gradle 在 sourceSets.main.resources 中增加了：

```groovy
exclude 'assets/bsfdcompat/textures/item/_drawing/**'
```

这样绘图底图、蔚蓝参考原图、索引和清单留在源项目，不作为运行资源打进 jar。
画完并放回正常物品纹理路径的图片仍会正常打包。
本次没有替换你的物品、方块或状态图标贴图。

覆盖后运行 `gradlew.bat clean build` 并重新启动游戏，检查两道主菜的效果提示和食用结果。
已完成的检查见 VALIDATION.md，尚未执行完整 Forge 构建或游戏内测试。
